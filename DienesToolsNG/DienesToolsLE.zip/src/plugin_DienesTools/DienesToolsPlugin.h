//Definately need these first four headers at least...
#include "skse/PluginAPI.h"
#include "skse/PapyrusArgs.h"
#include "skse/PapyrusVM.h"
#include "skse/PapyrusNativeFunctions.h"

//These will vary depending on what you are doing...
#include "skse/GameReferences.h"
#include "skse/GameData.h"
#include "skse/GameTypes.h"
#include "skse/GameFormComponents.h"
#include "skse/GameRTTI.h"

#include <math.h>

namespace DienesToolsPluginNamespace
{
	void GetAllCOBJThatYieldForm(StaticFunctionTag* base, TESForm* theForm, BGSListForm* theFormList);
	BGSConstructibleObject* TempCOBJ(StaticFunctionTag* base, BGSConstructibleObject* toCopy);
	void ReplaceKYWD(StaticFunctionTag* base, TESForm* theForm, BGSKeyword* toRemove, BGSKeyword* toAdd);


	bool RegisterFuncs(VMClassRegistry* registry);
}