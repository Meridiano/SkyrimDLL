#include "skse/PluginAPI.h"
#include "skse/skse_version.h"
#include "skse/SafeWrite.h"

//I don't think these two headers are needed for this particular example...
//#include "skse/ScaleformCallbacks.h"
//#include "skse/ScaleformMovie.h"

#include "DienesToolsPlugin.h"

//The log file for all your messages...
IDebugLog	gLog("DienesToolsPluginScript.log");

PluginHandle	g_pluginHandle = kPluginHandle_Invalid;

// here is a global reference to the interface, keeping to the skse style
SKSEPapyrusInterface        * g_papyrus = NULL;

extern "C"
{

bool SKSEPlugin_Query(const SKSEInterface * skse, PluginInfo * info)
{
	_MESSAGE("DienesToolsPluginScript");

	// populate info structure
	info->infoVersion =	PluginInfo::kInfoVersion;
	info->name =		"DienesToolsPluginScript";
	info->version =		1;

	// store plugin handle so we can identify ourselves later
	g_pluginHandle = skse->GetPluginHandle();

	if(skse->isEditor)
	{
		_MESSAGE("loaded in editor, marking as incompatible");

		return false;
	}
	else if(skse->runtimeVersion != RUNTIME_VERSION_1_9_32_0)
	{
		_MESSAGE("unsupported runtime version %08X", skse->runtimeVersion);

		return false;
	}

	// ### do not do anything else in this callback
	// ### only fill out PluginInfo and return true/false

	// supported runtime version
	return true;
}

bool SKSEPlugin_Load(const SKSEInterface * skse)
{
	_MESSAGE("DienesToolsPluginScript is loaded");

    g_papyrus = (SKSEPapyrusInterface *)skse->QueryInterface(kInterface_Papyrus);

	//Check if the function registration was a success...
	bool btest = g_papyrus->Register(DienesToolsPluginNamespace::RegisterFuncs);

    if (btest)
        _MESSAGE("Register Succeeded"); //example error check

	return true;
}

};
 