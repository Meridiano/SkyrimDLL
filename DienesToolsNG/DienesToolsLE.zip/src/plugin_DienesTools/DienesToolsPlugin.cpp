#include "DienesToolsPlugin.h"

namespace DienesToolsPluginNamespace
{

	/* Takes a FORM (WEAP or ARMO ?) and a formlist. Sets the contents of the formlist to the COBJs that yeild
		the FORM.
	*/
	void GetAllCOBJThatYieldForm(StaticFunctionTag* base, TESForm* theForm, BGSListForm* theFormList) {

		if (!theForm || !theFormList) {
			_DMESSAGE("NULL TESFORM OR NULL FORMLIST");
			return;
		}

		UInt32 theFormID = theForm->formID;
		DataHandler* theDataHandler = DataHandler::GetSingleton();

		tArray<BGSConstructibleObject*> theCOBJs = theDataHandler->constructibles;

		int count = theCOBJs.count;

		for(int i = 0; i<count; i++){
			BGSConstructibleObject* thisCOBJ = theCOBJs[i];

			TESForm* thisCreated = thisCOBJ->createdObject;
			if (thisCreated){
				UInt32 thisFormID = thisCreated->formID;
				if (theFormID == thisFormID) {
					CALL_MEMBER_FN(theFormList, AddFormToList)(thisCOBJ);
				}
			}

		}

	}

	/* Takes a ConstructibleObject and creates a TempClone that only only lasts that game session with the same
		inputs, product, workbench keyword, and hopefully conditions. Order of inputs may change.
	*/

	BGSConstructibleObject* TempCOBJ(StaticFunctionTag* base, BGSConstructibleObject* toCopy) {
		BGSConstructibleObject* result = NULL;

		if (toCopy){
			IFormFactory	* factory = IFormFactory::GetFactoryForType(toCopy->formType);
			if(factory)
			{
				result = (BGSConstructibleObject*) factory->Create();
				if(result)
				{
					result->Init();

					result->container.CopyFromBase(&toCopy->container);
					result->unk20 = toCopy->unk20;
					result->createdObject = toCopy->createdObject;
					result->wbKeyword = toCopy->wbKeyword;
					result->quantity = toCopy->quantity;
					result->pad2E[0] = toCopy->pad2E[0];
					result->pad2E[1] = toCopy->pad2E[1];

				}
				else
				{
					_ERROR("Form::TempClone: factory for type %02X failed", toCopy->formType);
				}
			}
			else
			{
				_MESSAGE("Form::TempClone: tried to clone form %08X (type %02X), no factory found", toCopy->formID, toCopy->formType);
			}
		}
		return result;
	}

	/* Takes a Form and two Keywords. If the first keyword is on the form and the second keyword is not
		then the first keyword will be replaced by the second. Only lasts for that skyrim game session.
	*/

	void ReplaceKYWD(StaticFunctionTag* base, TESForm* theForm, BGSKeyword* toRemove, BGSKeyword* toAdd) {
		if (!theForm || !toRemove || !toAdd) {
			_DMESSAGE("NULL TESFORM OR NULL BGSKeyword");
			return;
		}

		BGSKeywordForm* pKeywords = DYNAMIC_CAST(theForm, TESForm, BGSKeywordForm);
		if (pKeywords) {
			UInt32 removeIndex;
			bool found = false;
			for(UInt32 i = 0; i<pKeywords->numKeywords; i++) {
				BGSKeyword* thisKey = pKeywords->keywords[i];
				if (thisKey->keyword.Get() == toAdd->keyword.Get()) {
					return;
				}
				if (thisKey->keyword.Get() == toRemove->keyword.Get()){
					removeIndex = i;
					found = true;
				}
			}
			if(found) {
				pKeywords->keywords[removeIndex] = toAdd;
			}
		}
	}

	//Registering the functions here...
       //'NativeFunctionX' where 'X' is the number of arguments NOT including 
       //'StaticFunctionTag', then 'StaticFunctionTag', then the function return type,
       //THEN your argument types. The first string should be the name of your function
       //in Papyrus, the second string should be the name of the script it belongs to.
	bool RegisterFuncs(VMClassRegistry* registry)
	{
		registry->RegisterFunction(
			new NativeFunction2 <StaticFunctionTag, void, TESForm*, BGSListForm*>("GetAllCOBJThatYieldForm", "DienesToolsPluginScript", DienesToolsPluginNamespace::GetAllCOBJThatYieldForm, registry));
		registry->RegisterFunction(
			new NativeFunction1 <StaticFunctionTag, BGSConstructibleObject*, BGSConstructibleObject*>("TempCOBJ", "DienesToolsPluginScript", DienesToolsPluginNamespace::TempCOBJ, registry));
		registry->RegisterFunction(
			new NativeFunction3 <StaticFunctionTag, void, TESForm*, BGSKeyword*, BGSKeyword*>("ReplaceKYWD", "DienesToolsPluginScript", DienesToolsPluginNamespace::ReplaceKYWD, registry));
		
		//Optional flags...
		registry->SetFunctionFlags("DienesToolsPluginScript", "GetAllCOBJThatYieldForm", VMClassRegistry::kFunctionFlag_NoWait);
		registry->SetFunctionFlags("DienesToolsPluginScript", "TempCOBJ", VMClassRegistry::kFunctionFlag_NoWait);
		registry->SetFunctionFlags("DienesToolsPluginScript", "ReplaceKYWD", VMClassRegistry::kFunctionFlag_NoWait);

		return true;
	}
} 